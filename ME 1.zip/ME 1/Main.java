public class Main {
    public static void main(String[] args) {
        ConjuntoEspalhamento conjunto = new ConjuntoEspalhamento();

        conjunto.adiciona("australia");
        conjunto.adiciona("brasil");
        conjunto.adiciona("peru");
        conjunto.adiciona("espanha");
        conjunto.adiciona("angola");

        System.out.println("Testando nome de Paises");
        System.out.println(" ");

        System.out.println("O conjunto contém australia? " + conjunto.contem("australia"));
        System.out.println("O conjunto contém brasil? " + conjunto.contem("brasil"));
        System.out.println("O conjunto contém agentina? " + conjunto.contem("agentina"));
        System.out.println("O conjunto contém peru? " + conjunto.contem("peru"));
        System.out.println("O conjunto contém portugal? " + conjunto.contem("portugal"));
        System.out.println("O conjunto contém espanha? " + conjunto.contem("espanha"));
        System.out.println("O conjunto contém angola? " + conjunto.contem("angola"));

    }
}
